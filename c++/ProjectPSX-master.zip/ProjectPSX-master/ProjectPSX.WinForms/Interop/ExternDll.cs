﻿namespace ProjectPSX
{
    internal static class ExternDll
    {
        public const string Gdi32 = "gdi32.dll";
        public const string User32 = "user32.dll";
    }
}
